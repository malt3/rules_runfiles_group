# rules_java

[![Build status](https://badge.buildkite.com/d4f950ef5f481b8ca066624ba06c238fa1446d84a057ddbf89.svg?branch=master)](https://buildkite.com/bazel/rules-java-java)

Java Rules for Bazel https://bazel.build.

**Documentation**

For a quickstart tutorial, see https://bazel.build/start/java

The fastest way to try this in an empty project is to click the green "Use this template" button on https://github.com/bazel-starters/java.

For slightly more advanced usage, like setting up toolchains
or writing your own java-like rules,
see https://bazel.build/docs/bazel-and-java


***Core Java rules***

Add a load like:
```build
load("@rules_java//java:java_library.bzl", "java_library")
```
to your `BUILD` / `BUILD.bazel` / `*.bzl` files

For detailed docs on the core rules, see https://bazel.build/reference/be/java
