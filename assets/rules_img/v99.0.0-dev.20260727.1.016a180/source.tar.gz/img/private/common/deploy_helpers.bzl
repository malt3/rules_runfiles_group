"""Shared helper functions for push and load rules."""

load("@bazel_skylib//rules:common_settings.bzl", "BuildSettingInfo")
load("//img/private/providers:deploy_info.bzl", "DeployInfo")
load("//img/private/providers:index_info.bzl", "ImageIndexInfo")
load("//img/private/providers:load_settings_info.bzl", "LoadSettingsInfo")
load("//img/private/providers:manifest_info.bzl", "ImageManifestInfo")
load("//img/private/providers:push_settings_info.bzl", "PushSettingsInfo")
load("//img/private/providers:signing_config_info.bzl", "SigningConfigInfo")

def get_tags(ctx):
    """Get the list of tags from the context, validating mutual exclusivity.

    Args:
        ctx: Rule context with tag/tag_list attributes.

    Returns:
        List of tag strings (may be empty for digest-only push).
    """
    if ctx.attr.tag and ctx.attr.tag_list:
        fail("Cannot specify both 'tag' and 'tag_list' attributes")

    tags = []
    if ctx.attr.tag:
        tags = [ctx.attr.tag]
    elif ctx.attr.tag_list:
        tags = ctx.attr.tag_list

    return tags

def image_target_vars(label):
    """Extract package/name variables from an image label.

    Args:
        label: A Bazel label.

    Returns:
        Dict with image_target_package and image_target_name keys.
    """
    return {
        "image_target_package": label.package,
        "image_target_name": label.name,
    }

def get_image_providers(ctx):
    """Extract and validate image providers from ctx.attr.image.

    Args:
        ctx: Rule context with an image attribute.

    Returns:
        Tuple of (manifest_info, index_info) where exactly one is non-None.
    """
    manifest_info = ctx.attr.image[ImageManifestInfo] if ImageManifestInfo in ctx.attr.image else None
    index_info = ctx.attr.image[ImageIndexInfo] if ImageIndexInfo in ctx.attr.image else None
    if manifest_info == None and index_info == None:
        fail("image must provide ImageManifestInfo or ImageIndexInfo")
    if manifest_info != None and index_info != None:
        fail("image must provide either ImageManifestInfo or ImageIndexInfo, not both")
    return manifest_info, index_info

def resolve_push_registry(ctx):
    """Resolve and validate the push registry from context attributes.

    Args:
        ctx: Rule context with registry/repository/destination_file attributes.

    Returns:
        The resolved registry string (empty string when destination_file is used).
    """
    registry = ctx.attr.registry
    if not registry:
        registry = ctx.attr._destination_registry[BuildSettingInfo].value

    if ctx.attr.destination_file:
        if ctx.attr.registry:
            fail("Cannot specify both 'destination_file' and 'registry' attributes")
        if ctx.attr.repository:
            fail("Cannot specify both 'destination_file' and 'repository' attributes")
        registry = ""
    else:
        if not registry:
            fail("'registry' is required when 'destination_file' is not set")
        if not ctx.attr.repository:
            fail("'repository' is required when 'destination_file' is not set")

    return registry

def resolve_load_destination(ctx):
    """Resolve and validate the registry/repository for a load target.

    Like push, load supports the global `destination_registry` fallback, but
    only for the split `registry`/`repository` form: when `repository` is set
    and `registry` is empty, the `--@rules_img//img/settings:destination_registry`
    flag fills in the registry. The registry/repository must end up set together
    (to reconstruct `<registry>/<repository>:<tag>` image names) or both empty
    (backwards-compatible mode, where the tags are already full image
    references). In the backwards-compatible mode (empty `repository`) the
    fallback deliberately does not apply, so legacy `rules_oci`-style targets
    never get a registry injected.

    Args:
        ctx: Rule context with registry/repository attributes.

    Returns:
        Tuple (registry, repository) of the (possibly empty) resolved values.
    """
    registry = ctx.attr.registry
    repository = ctx.attr.repository

    # Fall back to the global destination_registry only for the split
    # registry/repository/tag form. Legacy usage (a single full-reference `tag`
    # with empty registry+repository) must NOT get a registry injected.
    if not registry and repository:
        registry = ctx.attr._destination_registry[BuildSettingInfo].value

    if bool(registry) != bool(repository):
        fail("image_load/image_load_spec: 'registry' and 'repository' must be set together (or neither); got registry = {}, repository = {}".format(
            repr(registry),
            repr(repository),
        ))
    return registry, repository

def resolve_push_strategy(ctx):
    """Determine the push strategy, resolving 'auto' from settings.

    Args:
        ctx: Rule context with strategy attribute and _push_settings.

    Returns:
        Resolved strategy string.
    """
    push_settings = ctx.attr._push_settings[PushSettingsInfo]
    strategy = ctx.attr.strategy
    if strategy == "auto":
        strategy = push_settings.strategy
    return strategy

def extract_referrers(ctx):
    """Extract referrer provider structs from ctx.attr.referrers.

    Args:
        ctx: Rule context with referrers attribute.

    Returns:
        List of struct(manifest_info, index_info).
    """
    referrers = []
    for referrer in ctx.attr.referrers:
        ref_manifest_info = referrer[ImageManifestInfo] if ImageManifestInfo in referrer else None
        ref_index_info = referrer[ImageIndexInfo] if ImageIndexInfo in referrer else None
        referrers.append(struct(manifest_info = ref_manifest_info, index_info = ref_index_info))
    return referrers

def extract_cross_mount_from(ctx):
    """Extract cross_mount_from DeployInfo if set.

    Args:
        ctx: Rule context with cross_mount_from attribute.

    Returns:
        DeployInfo or None.
    """
    return ctx.attr.cross_mount_from[DeployInfo] if ctx.attr.cross_mount_from != None else None

def resolve_load_strategy(ctx):
    """Determine the load strategy, resolving 'auto' from settings.

    Args:
        ctx: Rule context with strategy attribute and _load_settings.

    Returns:
        Resolved strategy string.
    """
    load_settings = ctx.attr._load_settings[LoadSettingsInfo]
    strategy = ctx.attr.strategy
    if strategy == "auto":
        strategy = load_settings.strategy
    return strategy

def content_tracking_json_vars(descriptor):
    """Build json_vars wiring that exposes the image digest for content tracking.

    When `tracks_content` is enabled, the image descriptor is passed through the
    `json_vars` path of `expand_or_write`. This both declares the descriptor as an
    input of the template-expansion action (so the tag re-stamps when the image
    content changes) and exposes the digest to templates as `{{.digest}}`.

    Args:
        descriptor: File containing the image descriptor (manifest/index), or None
            to disable content tracking.

    Returns:
        Tuple of (json_vars, json_path_to_root) suitable for `expand_or_write`.
        Both are None when descriptor is None.
    """
    if descriptor == None:
        return None, None
    return {"digest": descriptor}, {"digest": "digest"}

def resolve_daemon(ctx):
    """Determine the daemon to target, resolving 'auto' from settings.

    Args:
        ctx: Rule context with daemon attribute and _load_settings.

    Returns:
        Resolved daemon string.
    """
    load_settings = ctx.attr._load_settings[LoadSettingsInfo]
    daemon = ctx.attr.daemon
    if daemon == "auto":
        daemon = load_settings.daemon
    return daemon

def resolve_signing(ctx):
    """Resolve whether and how this push target is signed.

    Combines the per-target `sign` attribute (auto -> global //img/settings:sign)
    with the `sign_setting` attribute (or global //img/settings:sign_setting).

    Args:
        ctx: Rule context with sign/sign_setting attributes and _sign/_sign_setting.

    Returns:
        A struct(config_info, best_effort, targets) when signing is active, or
        None when signing is disabled or best-effort with no configured setting.
    """
    mode = ctx.attr.sign
    if mode == "auto":
        mode = ctx.attr._sign[BuildSettingInfo].value
    if mode == "disabled":
        return None

    config_info = ctx.attr.sign_setting[SigningConfigInfo] if ctx.attr.sign_setting != None else ctx.attr._sign_setting[SigningConfigInfo]
    if config_info.config_file == None:
        if mode == "enabled":
            fail("sign is 'enabled' but no sign_setting is configured; set the 'sign_setting' attribute or --@rules_img//img/settings:sign_setting")
        return None  # best_effort with no configured setting: nothing to sign

    return struct(
        config_info = config_info,
        best_effort = mode == "best_effort",
        targets = config_info.targets,
    )
