"""Shared stamping utilities for Bazel rules."""

load("@bazel_skylib//rules:common_settings.bzl", "BuildSettingInfo")
load("//img/private/common:build.bzl", "TOOLCHAIN")
load("//img/private/providers:stamp_setting_info.bzl", "StampSettingInfo")

def get_build_settings(ctx):
    """Extract build settings values from the context.

    Args:
        ctx: The rule context

    Returns:
        A dictionary mapping setting names to their values
    """
    settings = {}
    for setting_name, setting_label in ctx.attr.build_settings.items():
        settings[setting_name] = setting_label[BuildSettingInfo].value
    return settings

def should_stamp(*, ctx, template_strings, stamp_override = None, stamp_settings_override = None):
    """Get the stamp configuration from the context.

    Args:
        ctx: The rule context
        template_strings: List of strings to check for Go template placeholders ({{...}})
        stamp_override: If set, use this stamp preference instead of ctx.attr.stamp
        stamp_settings_override: If set, use this StampSettingInfo instead of ctx.attr._stamp_settings

    Returns:
        A struct containing stamp, can_stamp, and want_stamp boolean fields
    """
    stamp_settings = stamp_settings_override if stamp_settings_override != None else ctx.attr._stamp_settings[StampSettingInfo]
    bazel_stamp = stamp_settings.bazel_setting
    global_preference = stamp_settings.user_preference
    target_stamp = stamp_override if stamp_override != None else ctx.attr.stamp

    contains_template_placeholders = False
    for template in template_strings:
        open_pos = template.find("{{")
        if open_pos >= 0:
            close_pos = template.find("}}", open_pos + 2)
            if close_pos >= 0:
                contains_template_placeholders = True
                break

    if target_stamp != "auto":
        effective = target_stamp
    else:
        effective = global_preference

    want_stamp = False
    if effective == "disabled":
        want_stamp = False
    elif effective == "force":
        want_stamp = contains_template_placeholders
    elif effective == "auto":
        want_stamp = bazel_stamp and contains_template_placeholders
    return struct(
        stamp = want_stamp,
        can_stamp = bazel_stamp,
        want_stamp = want_stamp,
    )

def expand_or_write(*, ctx, templates, output_name, only_if_stamping = False, newline_delimited_lists_files = None, json_vars = None, json_path_to_root = None, expose_kvs = None, extra_build_settings = None, build_settings_override = None, stamp_override = None, stamp_settings_override = None):
    """Either expand templates or write JSON directly based on build_settings.

    Args:
        ctx: The rule context
        templates: The templates dictionary (dict of template name to value (str) or values (list of str))
        output_name: The name for the output file
        only_if_stamping: If True, only create the file if stamping is needed (templates contain {{}})
        newline_delimited_lists_files: Optional dict mapping template keys to File objects containing newline-delimited lists
        json_vars: Optional dict mapping variable paths (e.g., "parent.config") to File objects containing JSON
        json_path_to_root: Optional dict mapping json-var names to dot-separated paths selecting a sub-object as root
        expose_kvs: Optional list of template keys whose values are OCI-style key-value pair arrays to expose as template variables
        extra_build_settings: Optional dict of additional template variables (lowest precedence; overridden by `build_settings`)
        build_settings_override: Optional dict(string, string) to use instead of ctx.attr.build_settings
        stamp_override: Optional stamp preference string to use instead of ctx.attr.stamp
        stamp_settings_override: Optional StampSettingInfo to use instead of ctx.attr._stamp_settings

    Returns:
        The File object for the final JSON, or None if only_if_stamping=True and no stamping needed
    """
    if build_settings_override != None:
        build_settings = dict(build_settings_override)
    else:
        build_settings = get_build_settings(ctx)
    if extra_build_settings:
        merged = dict(extra_build_settings)
        merged.update(build_settings)
        build_settings = merged
    stamp_settings = should_stamp(ctx = ctx, template_strings = [json.encode(v) for v in templates.values()], stamp_override = stamp_override, stamp_settings_override = stamp_settings_override)

    # If only_if_stamping is True and no stamping is needed and no newline-delimited files or json_vars provided, return None
    if only_if_stamping and not stamp_settings.want_stamp and not newline_delimited_lists_files and not json_vars:
        return None

    final_json = ctx.actions.declare_file(output_name)

    # Determine if we need template expansion
    needs_expansion = build_settings or stamp_settings.want_stamp or newline_delimited_lists_files or json_vars

    if needs_expansion:
        # Add build settings to the request for template expansion
        request = dict(
            templates = templates,
            build_settings = build_settings,
        )

        # Add newline-delimited files if provided
        if newline_delimited_lists_files:
            ndl = {}
            for key, files in newline_delimited_lists_files.items():
                if type(files) == "list":
                    ndl[key] = [f.path for f in files]
                else:
                    ndl[key] = files.path
            request["newline_delimited_lists_files"] = ndl

        # Write the template JSON
        template_name = output_name.replace(".json", ".template_request.json")
        template_json = ctx.actions.declare_file(template_name)
        ctx.actions.write(
            template_json,
            json.encode(request),
        )

        # Run expand-template to create the final JSON

        # Build arguments for expand-template
        args = []
        inputs = [template_json]

        # Add newline-delimited list files as inputs
        if newline_delimited_lists_files:
            for files in newline_delimited_lists_files.values():
                if type(files) == "list":
                    inputs.extend(files)
                else:
                    inputs.append(files)

        # Add stamp files if stamping is active
        if stamp_settings.stamp:
            if ctx.version_file:
                args.extend(["--stamp", ctx.version_file.path])
                inputs.append(ctx.version_file)
            if ctx.info_file:
                args.extend(["--stamp", ctx.info_file.path])
                inputs.append(ctx.info_file)

        # Add json_vars files if provided
        if json_vars:
            for var_path, json_file in json_vars.items():
                args.extend(["--json-var", "{}={}".format(var_path, json_file.path)])
                inputs.append(json_file)
        if json_path_to_root:
            for var_name, root_path in json_path_to_root.items():
                args.extend(["--json-path-to-root", "{}={}".format(var_name, root_path)])
        if expose_kvs:
            for kv_path in expose_kvs:
                args.extend(["--expose-kv", kv_path])

        args.extend([template_json.path, final_json.path])

        img_toolchain_info = ctx.toolchains[TOOLCHAIN].imgtoolchaininfo
        ctx.actions.run(
            inputs = inputs,
            outputs = [final_json],
            executable = img_toolchain_info.tool_exe,
            arguments = ["expand-template"] + args,
            mnemonic = "ExpandTemplate",
        )
        return final_json
    else:
        # No templates to expand, create JSON directly
        ctx.actions.write(
            final_json,
            json.encode(templates),
        )
        return final_json
